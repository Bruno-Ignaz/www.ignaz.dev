{
  description = "My personal NeoVim configuration.";

  inputs = {
    nixpkgs.url = "github:nixos/nixpkgs/nixos-unstable";
    nixvim.url = "github:nix-community/nixvim";
    flake-utils.url = "github:numtide/flake-utils";
  };

  outputs = { self, nixpkgs, nixvim, flake-utils, ... }:
    flake-utils.lib.eachDefaultSystem (system:
      let
        pkgs = import nixpkgs { inherit system; };
        nixvim' = nixvim.legacyPackages.${system};
        
        nvim = nixvim'.makeNixvimWithModule {
          inherit pkgs;
          module = import ./nixvim.nix;
        };
      in
      {
        packages.default = nvim;
      }
    );
}
