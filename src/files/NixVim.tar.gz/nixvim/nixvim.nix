{ pkgs, ... }:
{
  extraPackages = [
    pkgs.tree-sitter
    pkgs.xclip
  ];
  # Core Options
  opts = {
    tabstop = 2;
    shiftwidth = 2;
    expandtab = true;
    splitright = true;
    splitbelow = true;
    number = true;
    relativenumber = true;
    completeopt = ["menu" "menuone"];
  };

  # Global Keymaps
  globals.mapleader = "\\";
  keymaps = [
    # custom
    { mode = "n"; key = "<space>e"; action = "<cmd>lua vim.diagnostic.open_float(0, {scope='line'})<CR>"; }
    { mode = "n"; key = "<space>e"; action = "<cmd>lua vim.diagnostic.open_float(0, {scope='line'})<CR>"; }

  ];

  # Colorscheme
  colorschemes.catppuccin = {
    enable = true;
    settings = {
      flavour = "mocha";
      color_overrides = {
        mocha = {
          base = "#000000";
        };
      };
      integrations = {
        cmp = true;
        gitsigns = true;
        nvimtree = true;
        treesitter = true;
        native_lsp.enabled = true;
      };
    };
  };

  plugins = {
    web-devicons.enable = true;

    # Nvim-Surround
    nvim-surround.enable = true;

    # Treesitter
    treesitter = {
      enable = true;

       settings = {
        # Performance optimizations for treesitter
        incremental_selection = { enable = true; };
        indent = { enable = false; }; # Keep disabled for performance
        textobjects.enable = true;

        highlight = {
          enable = true;

          # Optimize highlighting performance
          disable = ''
            function(lang, bufnr)
              local line_count = vim.api.nvim_buf_line_count(bufnr)
              -- Disable for very large files
              if line_count > 10000 then
                return true
              end
              -- Disable for certain large filetypes that don't need highlighting
              local ft = vim.bo[bufnr].filetype
              if ft == "help" or ft == "man" then
                return true
              end
              return false
            end
          '';

          # Reduce highlighting update frequency for performance
          additional_vim_regex_highlighting = false;
        };

        # Optimize parser loading
        auto_install = true; # Don't auto-install at runtime
        ensure_installed = [ ]; # All grammars are managed by Nix

        # Performance settings
        sync_install = false;
      };
    };

    # Oil File Explorer
    oil = {
      enable = true;
      settings = {
        default_file_explorer = true;
        columns = [ "icon" ];
        delete_to_trash = false;
        cleanup_delay_ms = false;
      };
    };

    # Telescope
    telescope = {
      enable = true;
      keymaps = {
          "<leader>ff" = "find_files";
          "<leader>fg" = "live_grep";
          "<leader>fb" = "buffers";
          #"<leader>fh" = "help_tags";
      };
    };

    # LSP Integration
    lsp = {
      enable = true;
      keymaps = {
        diagnostic = {
          "[d" = "goto_prev";
          "]d" = "goto_next";
          "<space>q" = "setloclist";
        };
        lspBuf = {
          "gD" = "declaration";
          "gd" = "definition";
          "K" = "hover";
          "gi" = "implementation";
          "<C-k>" = "signature_help";
          "<leader>D" = "type_definition";
          "<leader>rn" = "rename";
          "<leader>ca" = "code_action";
          "gr" = "references";
        };
      };
      servers = {
        # ci/cd
        cmake.enable = true;
        docker_language_server.enable = true;
        docker_compose_language_service.enable = true;
        nixd.enable = true;

        # programming
        clangd.enable = true;
        gopls.enable = true;
        kotlin_language_server.enable = true;
        jdtls.enable = true;
        csharp_ls.enable = true;
        jedi_language_server.enable = true;
        pyright.enable = true;

        # scripting
        lua_ls.enable = true;
        vimls.enable = true;
        bashls.enable = true;

        # web
        eslint.enable = true;
        ts_ls.enable = true;
        html.enable = true;
        htmx.enable = true;
        cssls.enable = true;

        # database
        sqls.enable = true;
        postgres_lsp.enable = true;
        jsonls.enable = true;
        yamlls.enable = true;

        # writing
        marksman.enable = true;
        ltex = {
          enable = true;
          settings.ltex = {
            language = "en-US";
            additionalRules.motherTongue = "de-DE";
          };
        };
      };
    };

    # Completion (CMP)
    cmp = {
      enable = true;
      settings = {
        mapping = {
          "<C-p>" = "cmp.mapping.select_prev_item()";
          "<C-n>" = "cmp.mapping.select_next_item()";
          "<Up>" = "cmp.mapping.select_prev_item()";
          "<Down>" = "cmp.mapping.select_next_item()";
          "<C-u>" = "cmp.mapping.scroll_docs(-4)";
          "<C-d>" = "cmp.mapping.scroll_docs(4)";
          "<Tab>" = "cmp.mapping.confirm({ behavior = cmp.ConfirmBehavior.Select, select = true })";
        };
        sources = [
          { name = "path"; }
          { name = "nvim_lsp"; }
          { name = "ultisnips"; }
          { name = "buffer"; }
        ];
      };
    };
  };

  # Custom Plugin Addition for Isabelle (Not natively packaged in Nixvim standard library)
  extraPlugins = [
    # You may need to package Isabelle/Isabelle-syn via pkgs.vimUtils.buildVimPlugin
  ];
}
